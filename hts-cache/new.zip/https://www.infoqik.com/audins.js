<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>aaPanel Website Firewall Free Edition</title>
<style>
*{margin:0;padding:0;color:#444}
body{font-size:14px;font-family:"宋体"}
.main{width:700px;margin:10% auto;}
.title{background: #20a53a;color: #fff;font-size: 16px;height: 40px;line-height: 40px;padding-left: 20px;}
.content{background-color:#f3f7f9; height:280px;border:1px dashed #c6d9b6;padding:20px}
.t1{border-bottom: 1px dashed #c6d9b6;color: #ff4000;font-weight: bold; margin: 0 0 20px; padding-bottom: 18px;}
.t2{margin-bottom:8px; font-weight:bold}
ol{margin:0 0 20px 22px;padding:0;}
ol li{line-height:30px}
</style>
</head>

<body>
	<div class="main">
		<div class="title">aaPanel Website Firewall Free Edition</div>
		<div class="content">
			<p class="t1">Your request has an illegal parameter and has been blocked by the webmaster settings!</p>
			<p class="t2">Possible reason: </p>
			<ol>
				<li>Your submission contains dangerous attack requests</li>
			</ol>
			<p class="t2">How to solve: </p>
			<ol>
				<li>Check the submission;</li>
				<li>If the website is hosted, please contact the space provider;</li>
				<li>For ordinary website visitors, please contact the webmaster;</li>
				<li>This is a false positive, please contact the aaPanel <a href="https://forum.aapanel.com/" target="_brank">https://forum.aapanel.com/</a></li>
			</ol>
		</div>
	</div>
</body>
</html>


